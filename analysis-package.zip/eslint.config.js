export { default } from '../eslint.config.js';
