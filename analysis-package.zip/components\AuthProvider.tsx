/* eslint-disable react-refresh/only-export-components */
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { API_BASE } from '../lib/api';
import { PumpajMessage } from './PumpajMessage';
import { useI18n } from './I18nProvider';

export type Plan = 'FREE' | 'PREMIUM';

export type Policy = {
  plan: Plan;
  maxHeight: number;
  maxAudioKbps: number;
  playlistMax: number;
  batchMax: number;
  concurrentJobs: number;
  allowSubtitles: boolean;
  allowChapters: boolean;
  allowMetadata: boolean;
  speedLimitKbps?: number;
};

type User = { id: string; email?: string; username?: string; plan: Plan } | null;
type LoginPayload = { username: string; password: string };
type RegisterPayload = { username: string; password: string; email?: string };

const POLICY_DEFAULTS: Record<Plan, Policy> = {
  FREE: {
    plan: 'FREE',
    maxHeight: 720,
    maxAudioKbps: 128,
    playlistMax: 10,
    batchMax: 2,
    concurrentJobs: 1,
    allowSubtitles: false,
    allowChapters: false,
    allowMetadata: false,
  },
  PREMIUM: {
    plan: 'PREMIUM',
    maxHeight: 4320,
    maxAudioKbps: 320,
    playlistMax: 300,
    batchMax: 10,
    concurrentJobs: 4,
    allowSubtitles: true,
    allowChapters: true,
    allowMetadata: true,
  },
};

type AuthCtx = {
  me: User;
  policy: Policy | null;
  token: string | null;
  loading: boolean;
  login: (payload: LoginPayload) => Promise<void>;
  register: (payload: RegisterPayload) => Promise<void>;
  logout: () => Promise<void>;
  setToken: (value: string | null) => void;
};

const Ctx = createContext<AuthCtx | null>(null);

/* ============================ i18n ============================ */

export type UiLanguage = 'sr' | 'en';
export type ShowcaseSlideId = 'overview' | 'workflow';

export type Translation = {
  hero: {
    badge: string;
    title: string;
    intro: string;
    highlights: Array<{ title: string; desc: string }>;
    tiles: Array<{ label: string; title: string; description: string }>;
  };
  login: {
    badge: string;
    title: string;
    subtitle: string;
    primaryButton: string;
    submittingLabel: string;
    features: Array<{ icon: string; title: string; description: string }>;
    benefits: Array<{ title: string; description: string }>;
    security: { title: string; features: string[] };
  };
  register: {
    badge: string;
    title: string;
    subtitle: string;
    primaryButton: string;
    submittingLabel: string;
  };
  tabs: { login: string; register: string };
  placeholders: { username: string; email: string; password: string; confirm: string };
  instructions: { login: string; register: string };
  errors: {
    missingCredentials: string;
    missingRegisterCredentials: string;
    passwordTooShort: string;
    passwordMismatch: string;
    operationFailed: string;
  };
  status: { loadingAccount: string; checkingSession: string };
  language: {
    switchLabel: string;
    switchTo: string;
    options: Record<UiLanguage, { short: string; title: string }>;
  };
  appShowcase: {
    badge: string;
    slides: Array<{
      id: ShowcaseSlideId;
      accent: string;
      title: string;
      description: string;
      highlights: Array<{ icon?: string; label: string; value: string }>;
      items: Array<{ icon?: string; title: string; description: string }>;
    }>;
  };
};

const UI_COPY: Record<UiLanguage, Translation> = {
  sr: {
    hero: {
      badge: 'Pumpaj Premium',
      title: 'Video Downloader',
      intro:
        'Preuzimaj video, audio, plej liste i titlove brže nego ikad. Jedan nalog, sve mogućnosti – bez čekanja i bez kompromisa.',
      highlights: [
        { title: 'Ultra brzi download', desc: 'Bez ograničenja brzine za svaki nalog.' },
        { title: 'Batch & Queue magija', desc: 'Pametno upravljanje redovima, pauza i nastavak.' },
        { title: 'Premium alati', desc: 'Sačuvaj plej liste, audio-only ekstrakcije i titlove.' },
      ],
      tiles: [
        { label: 'Realtime SSE', title: 'Živi progres', description: 'Status, brzina i ETA u jednom pogledu.' },
        { label: 'Desktop & Web', title: 'Dual-mode', description: 'Electron aplikacija + web iskustvo.' },
      ],
    },
    login: {
      badge: 'Dobrodošao nazad',
      title: 'Prijavi se i nastavi preuzimanje',
      subtitle: 'Unesi korisničko ime i lozinku i nastavi tamo gde si stao.',
      primaryButton: 'Prijavi se',
      submittingLabel: 'Prijavljivanje…',
      features: [
        { icon: '🚀', title: 'Brzina svetlosti', description: 'Neograničena brzina preuzimanja za sve korisnike' },
        { icon: '📱', title: 'Svugde dostupno', description: 'Web + desktop aplikacija za maksimalnu fleksibilnost' },
        { icon: '🎵', title: 'Audio majstor', description: 'Izdvoj audio u bilo kom formatu i kvalitetu' },
        { icon: '📊', title: 'Živa statistika', description: 'Prati progres u realnom vremenu preko SSE' },
      ],
      benefits: [
        { title: 'Premium bez čekanja', description: 'Svi korisnici dobijaju punu premium funkcionalnost od prvog dana.' },
        { title: 'Podrška za sve platforme', description: 'YouTube, Vimeo, TikTok, Instagram i 100+ drugih servisa.' },
        { title: 'Batch i queue sistem', description: 'Dodaj stotine URL-ova odjednom, pauziraj i nastavi kad hoćeš.' },
        { title: 'Sigurnost na prvom mestu', description: 'Lokalno čuvanje fajlova, bez deljenja sa trećim stranama.' },
      ],
      security: {
        title: 'Bezbednost i privatnost',
        features: [
          'Lokalna enkripcija svih korisničkih podataka',
          'Nema praćenja ili analitike treće strane',
          'Fajlovi se čuvaju lokalno na vašem uređaju',
          'HTTPS konekcije za sve komunikacije',
        ],
      },
    },
    register: {
      badge: 'Kreiraj nalog',
      title: 'Beskonačan premium od prvog dana',
      subtitle:
        'Registruj nalog za tren – svi korisnici dobijaju kompletan premium paket automatski.',
      primaryButton: 'Registruj se',
      submittingLabel: 'Kreiranje naloga…',
    },
    tabs: { login: 'Prijava', register: 'Registracija' },
    placeholders: {
      username: 'korisničko ime',
      email: 'email@domena.com',
      password: 'lozinka',
      confirm: 'potvrdi lozinku',
    },
    instructions: {
      login:
        'Nemaš nalog? Prebaci se na karticu „Registracija" iznad i popuni formu – svi dobijaju premium pristup automatski.',
      register:
        'Već imaš nalog? Izaberi „Prijava" iznad i uloguj se za nekoliko sekundi.',
    },
    errors: {
      missingCredentials: 'Unesi korisničko ime i lozinku.',
      missingRegisterCredentials: 'Unesi korisničko ime, email i lozinku.',
      passwordTooShort: 'Lozinka mora imati najmanje 6 karaktera.',
      passwordMismatch: 'Lozinke se ne poklapaju.',
      operationFailed: 'Operacija nije uspela.',
    },
    status: { loadingAccount: 'Učitavanje naloga…', checkingSession: 'Provera sesije…' },
    language: {
      switchLabel: 'Promena jezika',
      switchTo: 'Prebaci na',
      options: { sr: { short: 'SR', title: 'Srpski' }, en: { short: 'EN', title: 'Engleski' } },
    },
    appShowcase: {
      badge: 'O APLIKACIJI',
      slides: [
        {
          id: 'overview',
          accent: '',
          title: 'Napredni media downloader',
          description:
            'Pumpaj kombinuje brzinu, stabilnost i sigurnost da uhvati svaki izvor sadržaja za par sekundi.',
          highlights: [
            { icon: '🌐', label: 'Servisa', value: '100+' },
            { icon: '📺', label: 'Kvalitet', value: 'Do 8K HDR' },
            { icon: '⚡', label: 'Batch', value: '300 URL-a' },
          ],
          items: [
            { icon: '⚡', title: 'Turbo preuzimanje', description: 'Pametna optimizacija konekcija bez ograničenja brzine.' },
            { icon: '💾', title: 'Lokalna kontrola', description: 'Sve datoteke ostaju na tvom uređaju – bez cloud sinhronizacije.' },
            { icon: '🔄', title: 'Queue orkestracija', description: 'Pauziraj, nastavi i rasporedi preuzimanja za nekoliko sekundi.' },
            { icon: '🎯', title: 'Precizno targetiranje', description: 'Automatsko prepoznavanje optimalnog kvaliteta za svaki tip sadržaja.' },
            { icon: '🛡️', title: 'Sigurnost i privatnost', description: 'End-to-end enkripcija i potpuna kontrola nad vašim podacima.' },
          ],
        },
        {
          id: 'workflow',
          accent: '',
          title: 'Preuzmi sve što vidiš',
          description:
            'Od linka do gotovog fajla u par klikova – kreirano za kreatore sadržaja i timove.',
          highlights: [
            { icon: '▶️', label: 'Start', value: '2 klika' },
            { icon: '📡', label: 'Monitoring', value: 'Live SSE' },
            { icon: '💻', label: 'Platforme', value: 'Web + Desktop' },
          ],
          items: [
            { icon: '🧠', title: 'Auto izbor kvaliteta', description: 'Aplikacija prepoznaje optimalan format i bitrate automatski.' },
            { icon: '🎚️', title: 'Napredne kontrole', description: 'Trimovanje, konverzija i ekstrakcija bez dodatnih alata.' },
            { icon: '📊', title: 'Progres bez kašnjenja', description: 'Precizan ETA, brzina i logovi u realnom vremenu.' },
            { icon: '🎨', title: 'Kreativne mogućnosti', description: 'Ekstraktuj thumbnail-e, GIF animacije i audio sample-e sa jednim klikom.' },
            { icon: '🔧', title: 'Prilagodljive opcije', description: 'Definisai custom output foldere, file naming pattern-e i post-processing komande.' },
          ],
        },
      ],
    },
  },
  en: {
    hero: {
      badge: 'Pumpaj Premium',
      title: 'Video Downloader',
      intro:
        'Download video, audio, playlists, and subtitles faster than ever. One account, all features—no waiting and no limits.',
      highlights: [
        { title: 'Blazing-fast downloads', desc: 'No throttling, full speed for every account.' },
        { title: 'Batch & queue magic', desc: 'Smart queue control with pause and resume.' },
        { title: 'Premium tools', desc: 'Save playlists, extract audio-only, and keep subtitles.' },
      ],
      tiles: [
        { label: 'Realtime SSE', title: 'Live progress', description: 'Status, speed, and ETA at a glance.' },
        { label: 'Desktop & Web', title: 'Dual-mode', description: 'Electron app plus polished web experience.' },
      ],
    },
    login: {
      badge: 'Welcome back',
      title: 'Sign in and keep downloading',
      subtitle: 'Enter your username and password to pick up right where you left off.',
      primaryButton: 'Sign in',
      submittingLabel: 'Signing in…',
      features: [
        { icon: '🚀', title: 'Lightning speed', description: 'Unlimited download speeds for all users' },
        { icon: '📱', title: 'Everywhere access', description: 'Web + desktop app for maximum flexibility' },
        { icon: '🎵', title: 'Audio master', description: 'Extract audio in any format and quality' },
        { icon: '📊', title: 'Live statistics', description: 'Track progress in real-time via SSE' },
      ],
      benefits: [
        { title: 'Premium without waiting', description: 'All users get full premium functionality from day one.' },
        { title: 'All platforms supported', description: 'YouTube, Vimeo, TikTok, Instagram and 100+ other services.' },
        { title: 'Batch and queue system', description: 'Add hundreds of URLs at once, pause and resume anytime.' },
        { title: 'Security first', description: 'Local file storage, no sharing with third parties.' },
      ],
      security: {
        title: 'Security and privacy',
        features: [
          'Local encryption of all user data',
          'No tracking or third-party analytics',
          'Files stored locally on your device',
          'HTTPS connections for all communications',
        ],
      },
    },
    register: {
      badge: 'Create your account',
      title: 'Unlimited premium from day one',
      subtitle:
        'Register instantly—every new member receives the full premium bundle automatically.',
      primaryButton: 'Sign up',
      submittingLabel: 'Creating account…',
    },
    tabs: { login: 'Sign in', register: 'Register' },
    placeholders: {
      username: 'username',
      email: 'email@domain.com',
      password: 'password',
      confirm: 'confirm password',
    },
    instructions: {
      login:
        'No account yet? Switch to the "Register" tab above and fill out the form—everyone gets premium access automatically.',
      register:
        'Already have an account? Choose "Sign in" above and you\'ll be in within seconds.',
    },
    errors: {
      missingCredentials: 'Enter your username and password.',
      missingRegisterCredentials: 'Enter your username, email and password.',
      passwordTooShort: 'Password must be at least 6 characters long.',
      passwordMismatch: 'Passwords do not match.',
      operationFailed: 'The operation failed.',
    },
    status: { loadingAccount: 'Loading account…', checkingSession: 'Checking session…' },
    language: {
      switchLabel: 'Language',
      switchTo: 'Switch to',
      options: { sr: { short: 'SR', title: 'Serbian' }, en: { short: 'EN', title: 'English' } },
    },
    appShowcase: {
      badge: 'ABOUT THE APP',
      slides: [
        {
          id: 'overview',
          accent: '',
          title: 'Advanced media downloader',
          description:
            'Pumpaj blends speed, reliability, and privacy to capture any media source in seconds.',
          highlights: [
            { icon: '🌐', label: 'Services', value: '100+' },
            { icon: '📺', label: 'Quality', value: 'Up to 8K HDR' },
            { icon: '⚡', label: 'Batch', value: '300 URLs' },
          ],
          items: [
            { icon: '🚀', title: 'Turbo transfers', description: 'Smart connection pooling with zero throttling.' },
            { icon: '💾', title: 'Local-first', description: 'Everything stays on your device—no cloud uploads.' },
            { icon: '🔄', title: 'Queue orchestration', description: 'Pause, resume, and reorder downloads instantly.' },
            { icon: '🎯', title: 'Precision targeting', description: 'Auto-detection of optimal quality for every content type.' },
            { icon: '🛡️', title: 'Security & privacy', description: 'End-to-end encryption with complete data ownership.' },
          ],
        },
        {
          id: 'workflow',
          accent: '',
          title: 'Grab anything you see',
          description:
            'From link to finished file in a couple clicks—built for creators and teams.',
          highlights: [
            { icon: '▶️', label: 'Start', value: '2 clicks' },
            { icon: '📡', label: 'Monitoring', value: 'Live SSE' },
            { icon: '💻', label: 'Platforms', value: 'Web + Desktop' },
          ],
          items: [
            { icon: '🧠', title: 'Auto quality pick', description: 'Detects the optimal format and bitrate automatically.' },
            { icon: '🎚️', title: 'Advanced adjustments', description: 'Trim, convert, and extract without external tools.' },
            { icon: '📊', title: 'Instant progress', description: 'Accurate ETA, speed, and logs in real time.' },
            { icon: '🎨', title: 'Creative capabilities', description: 'Extract thumbnails, GIF animations and audio samples with one click.' },
            { icon: '🔧', title: 'Customizable options', description: 'Define custom output folders, file naming patterns and post-processing commands.' },
          ],
        },
      ],
    },
  },
};

export const LANGUAGE_SEQUENCE: UiLanguage[] = ['sr', 'en'];

/* ============================ Auth Provider ============================ */

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const isBrowser = typeof window !== 'undefined';
  const isIpc = isBrowser && Boolean((window as any).api?.auth);

  const [token, setTokenState] = useState<string | null>(() => {
    if (!isBrowser) return null;
    try { return localStorage.getItem('app:token'); } catch { return null; }
  });

  const [me, setMe] = useState<User>(null);
  const [policy, setPolicy] = useState<Policy | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const setToken = useCallback((value: string | null) => {
    setTokenState(value);
    if (!isBrowser) return;
    try {
      if (value) localStorage.setItem('app:token', value);
      else localStorage.removeItem('app:token');
    } catch {}
  }, [isBrowser]);

  const applyUser = useCallback((data: any) => {
    const user = normalizeUser(data?.user) || null;
    setMe(user);
    if (data?.policy) setPolicy(data.policy as Policy);
    else setPolicy(derivePolicy(user?.plan));
  }, []);

  const fetchMeBearer = useCallback(async (tok: string) => {
    const res = await fetch(`${API_BASE}/api/me`, { headers: { Authorization: `Bearer ${tok}` } });
    if (!res.ok) throw new Error('unauthorized');
    const data = await res.json();
    applyUser(data);
  }, [applyUser]);

  const fetchMeCookie = useCallback(async () => {
    const res = await fetch(`${API_BASE}/api/me`, { credentials: 'include' });
    if (!res.ok) throw new Error('unauthorized');
    const data = await res.json();
    applyUser(data);
  }, [applyUser]);

  useEffect(() => {
    let cancelled = false;

    if (isIpc) {
      setLoading(true);
      (async () => {
        try {
          const res = await (window as any).api?.auth?.whoami?.();
          if (!cancelled) {
            if (res?.ok && res.user) {
              const user = normalizeUser(res.user);
              setMe(user);
              setPolicy(derivePolicy(user?.plan));
            } else {
              setMe(null);
              setPolicy(null);
            }
          }
        } finally {
          if (!cancelled) setLoading(false);
        }
      })();

      const unsubscribe = (window as any).api?.auth?.onState?.((payload: any) => {
        if (cancelled) return;
        const user = normalizeUser(payload?.user) || null;
        setMe(user);
        setPolicy(user ? derivePolicy(user.plan) : null);
      });

      return () => { cancelled = true; unsubscribe?.(); };
    }

    (async () => {
      setLoading(true);
      try {
        if (token) await fetchMeBearer(token);
        else await fetchMeCookie();
      } catch {
        setMe(null); setPolicy(null);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => { cancelled = true; };
  }, [isIpc, token, fetchMeBearer, fetchMeCookie]);

  const login = useCallback(async ({ username, password }: LoginPayload) => {
    const name = String(username || '').trim();
    const pwd = String(password || '');
    if (!name || !pwd) throw new Error('missing_credentials');

    if (isIpc) {
      const res = await (window as any).api?.auth?.login?.({ username: name, password: pwd });
      if (!res?.ok) throw new Error(res?.error || 'login_failed');
      const user = normalizeUser(res.user);
      setMe(user); setPolicy(derivePolicy(user?.plan));
      try { localStorage.setItem('app:lastUsername', name); } catch {}
      return;
    }

    const res = await fetch(authUrl('/login'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ username: name, password: pwd }),
    });

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data?.error || `login_failed_${res.status}`);
    }

    const data = await res.json().catch(() => ({}));
    if (data?.token) {
      setToken(data.token);
      await fetchMeBearer(data.token);
    } else {
      await fetchMeCookie();
    }
    try { localStorage.setItem('app:lastUsername', name); } catch {}
  }, [isIpc, fetchMeBearer, fetchMeCookie, setToken]);

  const register = useCallback(async ({ username, password, email }: RegisterPayload) => {
    const name = String(username || '').trim();
    const mail = email ? String(email).trim() : undefined;
    const pwd = String(password || '');
    if (!name || !pwd) throw new Error('missing_credentials');
    if (pwd.length < 6) throw new Error('password_too_short');

    if (isIpc) {
      const res = await (window as any).api?.auth?.register?.({ username: name, password: pwd, email: mail });
      if (!res?.ok) throw new Error(res?.error || 'register_failed');
      await login({ username: name, password: pwd });
      if (mail) { try { localStorage.setItem('app:lastEmail', mail); } catch {} }
      return;
    }

    const res = await fetch(authUrl('/register'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ username: name, password: pwd, email: mail }),
    });

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data?.error || `register_failed_${res.status}`);
    }

    const data = await res.json().catch(() => ({}));
    if (data?.token) {
      setToken(data.token);
      await fetchMeBearer(data.token);
    } else {
      await login({ username: name, password: pwd });
    }

    try {
      localStorage.setItem('app:lastUsername', name);
      if (mail) localStorage.setItem('app:lastEmail', mail);
    } catch {}
  }, [isIpc, login, fetchMeBearer, setToken]);

  const logout = useCallback(async () => {
    if (isIpc) {
      try { await (window as any).api?.auth?.logout?.(); } catch {}
    } else {
      try { await fetch(authUrl('/logout'), { method: 'POST', credentials: 'include' }); } catch {}
    }
    setToken(null); setMe(null); setPolicy(null);
  }, [isIpc, setToken]);

  const ctxValue = useMemo(
    () => ({ me, policy, token, loading, login, register, logout, setToken }),
    [me, policy, token, loading, login, register, logout, setToken],
  );

  return <Ctx.Provider value={ctxValue}>{children}</Ctx.Provider>;
}

/* ============================ Hooks ============================ */

export function useAuth() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

export function usePolicy(defaultPlan: Plan = 'PREMIUM') {
  const { policy } = useAuth();
  return policy ?? POLICY_DEFAULTS[defaultPlan];
}

/* ============================ Login Gate (UI) ============================ */

export function LoginGate({ children }: { children: React.ReactNode }) {
  const { me, login, register, loading } = useAuth();
  const isBrowser = typeof window !== 'undefined';
  const isIpc = isBrowser && Boolean((window as any).api?.auth);
  const { locale, setLocale } = useI18n();
  const language = useMemo<UiLanguage>(() => (locale === 'sr' ? 'sr' : 'en'), [locale]);

  const [mode, setMode] = useState<'login' | 'register'>('login');

  const [currentLeftView, setCurrentLeftView] = useState<ShowcaseSlideId>('overview');

  const copy = useMemo(() => UI_COPY[language], [language]);
  const activeFormCopy = mode === 'login' ? copy.login : copy.register;
  const showcaseSlides = copy.appShowcase.slides;
  const activeShowcase = useMemo(
    () => showcaseSlides.find(s => s.id === currentLeftView) ?? showcaseSlides[0],
    [showcaseSlides, currentLeftView],
  );

  const [username, setUsername] = useState<string>(() => {
    if (!isBrowser) return '';
    try { return localStorage.getItem('app:lastUsername') || ''; } catch { return ''; }
  });
  const [email, setEmail] = useState<string>(() => {
    if (!isBrowser) return '';
    try { return localStorage.getItem('app:lastEmail') || ''; } catch { return ''; }
  });
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [showPumpajInfo, setShowPumpajInfo] = useState(false);

  // rotate left slides
  useEffect(() => {
    if (!showcaseSlides.length) return;
    const ids = showcaseSlides.map(s => s.id);
    const t = setInterval(() => {
      setCurrentLeftView(cur => {
        const i = ids.indexOf(cur);
        const n = i === -1 ? 0 : (i + 1) % ids.length;
        return ids[n] ?? ids[0];
      });
    }, 5000);
    return () => clearInterval(t);
  }, [showcaseSlides]);

  // persist lang
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !submitting) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleSubmit = async () => {
    setError('');
    const name = username.trim();
    const mail = mode === 'register' ? email.trim() : '';
    const pwd = password;

    if (mode === 'login') {
      if (!name || !pwd) { setError(copy.errors.missingCredentials); return; }
    } else {
      if (!name || !mail || !pwd) { setError(copy.errors.missingRegisterCredentials); return; }
      if (pwd.length < 6) { setError(copy.errors.passwordTooShort); return; }
    }

    setSubmitting(true);
    try {
      if (mode === 'login') {
        await login({ username: name, password: pwd });
      } else {
        await register({ username: name, password: pwd, email: mail || undefined });
      }
      try {
        localStorage.setItem('app:lastUsername', name);
        if (mail) localStorage.setItem('app:lastEmail', mail);
      } catch {}
      setPassword('');
    } catch (e: any) {
      setError(e?.message ? String(e.message) : copy.errors.operationFailed);
    } finally {
      setSubmitting(false);
    }
  };

  // modal ESC
  useEffect(() => {
    if (!showPumpajInfo) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setShowPumpajInfo(false); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [showPumpajInfo]);

  if (isIpc) {
    if (loading && !me) {
      return <div className="min-h-screen flex items-center justify-center bg-slate-900 text-white text-sm">{copy.status.loadingAccount}</div>;
    }
    return <>{children}</>;
  }

  if (loading) {
    return null;
  }

  if (me) return <>{children}</>;

  return (
    <div className="relative min-h-screen overflow-hidden bg-slate-950 text-white">
      {/* background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -inset-[140px] bg-[radial-gradient(40%_60%_at_0%_0%,rgba(59,130,246,0.35),transparent_60%),radial-gradient(35%_55%_at_100%_10%,rgba(236,72,153,0.30),transparent_62%),radial-gradient(45%_60%_at_20%_100%,rgba(14,165,233,0.28),transparent_68%)] opacity-70" />
        <div className="absolute left-1/2 top-1/2 h-[720px] w-[720px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-br from-blue-500/20 via-purple-500/10 to-emerald-500/20 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(15,23,42,0.0),rgba(15,23,42,0.78))]" />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col p-6">
        {/* Enhanced Premium Header */}
        <div className="w-full max-w-6xl mx-auto">
          <div className="relative rounded-t-2xl border-x-2 border-t-2 border-blue-500/30 bg-gradient-to-r from-blue-900/20 via-slate-900/30 to-purple-900/20 p-4 backdrop-blur-xl shadow-lg overflow-hidden">
            {/* Animated background effects */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 via-purple-600/5 to-pink-600/10 opacity-70"></div>
            <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-blue-400/20 to-transparent rounded-full blur-xl animate-pulse"></div>
            <div className="absolute bottom-0 right-0 w-40 h-40 bg-gradient-to-tl from-purple-400/15 to-transparent rounded-full blur-2xl animate-pulse delay-1000"></div>
            
            <div className="relative z-10 flex items-center justify-between">
              {/* Left - Logo + Title + Features */}
              <div className="flex items-center gap-6">
                  {/* Enhanced logo with glow */}
                  <div className="relative group ml-4">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500/30 to-purple-500/30 rounded-2xl blur-md group-hover:blur-lg transition-all duration-300"></div>
                    <img src="/pumpaj-192.png?v=3" alt="Pumpaj logo" className="relative h-32 w-48 rounded-2xl shadow-xl" />
                  </div>                  {/* Title and features */}
                  <div className="flex flex-col gap-6 ml-4">
                    <div className="flex items-center justify-center gap-3">
                      <h1 className="text-5xl font-black bg-gradient-to-r from-white via-blue-200 to-purple-200 bg-clip-text text-transparent flex items-center gap-5">
                        Video 
                        <span className="bg-gradient-to-r from-green-400 via-emerald-500 to-green-600 rounded-xl px-5 py-3 text-2xl font-bold text-white shadow-xl border border-green-400/30 animate-pulse">
                          PRO
                        </span>
                        Downloader
                      </h1>
                    </div>
                    
                    {/* Premium features showcase */}
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-blue-500/20 border border-blue-400/30 hover:bg-blue-500/30 hover:scale-105 transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/20">
                        <span className="text-blue-300">⚡</span>
                        <span className="text-blue-200 font-medium">100+ Platforms</span>
                      </div>
                      <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-purple-500/20 border border-purple-400/30 hover:bg-purple-500/30 hover:scale-105 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/20">
                        <span className="text-purple-300">🎵</span>
                        <span className="text-purple-200 font-medium">8K Quality</span>
                      </div>
                      <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-400/30 hover:bg-emerald-500/30 hover:scale-105 transition-all duration-300 hover:shadow-lg hover:shadow-emerald-500/20">
                        <span className="text-emerald-300">🚀</span>
                        <span className="text-emerald-200 font-medium">Unlimited Speed</span>
                      </div>
                      <div className="relative flex items-center gap-2 px-3 py-1.5 rounded-lg bg-gradient-to-r from-pink-500/30 via-purple-500/25 to-pink-500/30 border-2 border-pink-400/50 hover:from-pink-500/40 hover:via-purple-500/35 hover:to-pink-500/40 hover:scale-110 transition-all duration-500 hover:shadow-2xl hover:shadow-pink-500/30 animate-pulse">
                        <span className="relative text-pink-300 text-lg animate-bounce">✨</span>
                        <span className="relative text-pink-200 font-bold text-base bg-gradient-to-r from-pink-200 via-white to-pink-200 bg-clip-text text-transparent">FREE PREMIUM</span>
                        <span className="relative text-pink-300 text-lg animate-bounce delay-100">✨</span>
                      </div>
                    </div>
                </div>
              </div>

              {/* Right - Perfect Language switcher */}
              <div className="relative">
                <div className="relative flex flex-col rounded-xl border border-purple-400/40 bg-gradient-to-b from-slate-900/80 via-blue-900/60 to-purple-900/80 p-1 backdrop-blur-xl shadow-lg">
                  {LANGUAGE_SEQUENCE.map((code) => {
                    const isActive = language === code;
                    return (
                      <button
                        key={code}
                        type="button"
                        onClick={() => setLocale(code)}
                        className={`relative rounded-lg px-12 py-3.5 text-lg font-bold uppercase transition-all duration-300 ${
                          isActive
                            ? 'bg-gradient-to-b from-purple-600 via-blue-600 to-purple-600 text-white shadow-lg scale-105'
                            : 'text-white/60 hover:text-white hover:bg-white/10 hover:scale-102'
                        }`}
                      >
                        <span className="relative z-10 flex flex-col items-center gap-1">
                          <span className="text-xl">{code === 'sr' ? '🇷🇸' : '🇬🇧'}</span>
                          <span className={`tracking-wider text-sm ${isActive ? 'text-white' : ''}`}>
                            {code === 'sr' ? 'RS' : 'EN'}
                          </span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main content area - connected to header */}
        <div className="w-full max-w-6xl mx-auto">
          <div className="relative rounded-b-2xl border-x-2 border-b-2 border-blue-500/30 bg-gradient-to-br from-blue-900/10 via-slate-900/20 to-purple-900/10 p-3 backdrop-blur-sm shadow-xl ring-1 ring-white/10">
            {/* Main grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
          {/* Left: app showcase */}
          <div className="h-[650px]">
            <div className="h-full rounded-xl border border-blue-500/30 bg-gradient-to-br from-blue-900/25 via-slate-900/30 to-purple-900/20 p-3 backdrop-blur-xl overflow-hidden">
              <div className="flex h-full flex-col gap-4">
                <div className="text-center space-y-3 flex-shrink-0">
                  {/* ABOUT THE APP badge SA KONTAKTIMA U ISTOM REDU */}
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-blue-500/20 rounded-xl blur-lg"></div>
                    <div className="relative flex items-center justify-center gap-4 rounded-xl px-10 py-5 border-2 bg-gradient-to-r from-blue-500/40 via-purple-500/40 to-blue-500/40 border-blue-400/60 backdrop-blur-sm shadow-xl">
                      <span className="text-2xl">�</span>
                      <span className="relative z-10 text-2xl font-bold uppercase tracking-[0.1em] text-white">
                        {copy.appShowcase.badge}
                      </span>
                      <span className="text-2xl">🚀</span>
                    </div>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-blue-500/20 rounded-xl blur-lg"></div>
                    <div className="relative flex items-center justify-between rounded-xl px-8 py-4 border-2 bg-gradient-to-r from-blue-500/40 via-purple-500/40 to-blue-500/40 border-blue-400/60 backdrop-blur-sm shadow-xl">
                      {/* Leva strana: ABOUT THE APP + PUMPAJ ikonica */}
                      <div className="flex items-center gap-3">
                        <span className="text-xl font-bold uppercase tracking-[0.1em] text-white">
                          {copy.appShowcase.badge}
                        </span>
                        {/* PUMPAJ ikonica */}
                        <span className="text-lg">🎬</span>
                      </div>
                      
                      {/* Desna strana: Kontakt ikonice + O PROGRAMU */}
                      <div className="flex items-center gap-3">
                        {/* GitHub */}
                        <a 
                          href="https://github.com/zoxknez" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center justify-center w-8 h-8 bg-gray-800/60 hover:bg-gray-700/80 rounded-md transition-all duration-300 hover:scale-110 border border-gray-600/50"
                          title="GitHub: zoxknez"
                        >
                          <span className="text-sm">🐙</span>
                        </a>

                        {/* Email */}
                        <a 
                          href="mailto:zoxknez@hotmail.com" 
                          className="flex items-center justify-center w-8 h-8 bg-blue-600/60 hover:bg-blue-500/80 rounded-md transition-all duration-300 hover:scale-110 border border-blue-500/50"
                          title="Email: zoxknez@hotmail.com"
                        >
                          <span className="text-sm">📧</span>
                        </a>

                        {/* PayPal */}
                        <a 
                          href="https://paypal.me/zoxknez" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center justify-center w-8 h-8 bg-yellow-600/60 hover:bg-yellow-500/80 rounded-md transition-all duration-300 hover:scale-110 border border-yellow-500/50"
                          title="PayPal Donacija"
                        >
                          <span className="text-sm">💰</span>
                        </a>

                        {/* O PROGRAMU ikonica */}
                        <button 
                          onClick={() => setShowPumpajInfo(true)}
                          className="flex items-center justify-center w-8 h-8 bg-purple-600/60 hover:bg-purple-500/80 rounded-md transition-all duration-300 hover:scale-110 border border-purple-500/50"
                          title="O PROGRAMU - Informacije o aplikaciji"
                        >
                          <span className="text-sm">ℹ️</span>
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-sm uppercase tracking-[0.2em] text-blue-200/70">{activeShowcase?.accent}</p>
                  <h2 className="text-2xl font-bold text-white">{activeShowcase?.title}</h2>
                  <p className="text-sm text-white/70 px-2 leading-relaxed line-clamp-4 min-h-[80px]">
                    {activeShowcase?.description}
                  </p>
                  <div className="flex justify-center gap-2 pt-2">
                    {showcaseSlides.map(slide => (
                      <span key={slide.id} className={`h-2 w-10 rounded-full transition-all ${slide.id === currentLeftView ? 'bg-blue-400 shadow-[0_0_12px_rgba(59,130,246,0.6)]' : 'bg-white/15'}`} />
                    ))}
                  </div>
                </div>

                {activeShowcase && (
                  <div className="flex-1 flex flex-col gap-2 text-white/85 text-sm">
                    <div className="grid grid-cols-3 gap-2">
                      {activeShowcase.highlights.map(({ icon, label, value }) => (
                        <div key={label} className="rounded-lg border border-white/10 bg-white/5 px-2 py-3 text-center shadow-inner">
                          {icon && <div className="text-lg">{icon}</div>}
                          <div className="mt-1 text-xs uppercase tracking-wider text-white/60">{label}</div>
                          <div className="text-base font-bold text-white">{value}</div>
                        </div>
                      ))}
                    </div>

                    <div className="space-y-1.5 overflow-y-auto pr-1 flex-1">
                      {activeShowcase.items.map(({ icon, title, description }) => (
                        <div key={title} className="flex items-start gap-3 rounded-lg border border-white/10 bg-white/5 p-2.5 shadow-sm min-h-[90px]">
                          {icon && <span className="text-lg flex-shrink-0">{icon}</span>}
                          <div className="space-y-1 min-w-0">
                            <h3 className="text-xs font-semibold text-white">{title}</h3>
                            <p className="text-xs text-white/70 leading-snug line-clamp-3">{description}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Developer Contact Links - DODANO U POSTOJEĆU SEKCIJU */}
                    <div className="pt-3 border-t border-white/10">
                      <h4 className="text-sm font-bold text-white mb-3 text-center">👨‍� KONTAKT DEVELOPER</h4>
                      <div className="grid grid-cols-3 gap-2">
                        {/* GitHub */}
                        <a 
                          href="https://github.com/zoxknez" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex flex-col items-center gap-1 bg-gray-800/60 hover:bg-gray-700/80 rounded-lg p-2 transition-all duration-300 hover:scale-105 border border-gray-600/50"
                        >
                          <span className="text-lg">🐙</span>
                          <span className="text-xs text-white font-medium">GitHub</span>
                        </a>

                        {/* Email */}
                        <a 
                          href="mailto:zoxknez@hotmail.com" 
                          className="flex flex-col items-center gap-1 bg-blue-600/60 hover:bg-blue-500/80 rounded-lg p-2 transition-all duration-300 hover:scale-105 border border-blue-500/50"
                        >
                          <span className="text-lg">📧</span>
                          <span className="text-xs text-white font-medium">Email</span>
                        </a>

                        {/* PayPal */}
                        <a 
                          href="https://paypal.me/zoxknez" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex flex-col items-center gap-1 bg-yellow-600/60 hover:bg-yellow-500/80 rounded-lg p-2 transition-all duration-300 hover:scale-105 border border-yellow-500/50"
                        >
                          <span className="text-lg">💰</span>
                          <span className="text-xs text-white font-medium">Donacija</span>
                        </a>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right: auth card */}
          <div className="h-[650px]">
            <div className="h-full rounded-xl border border-purple-500/30 bg-gradient-to-br from-purple-900/20 to-blue-900/20 p-3 backdrop-blur-xl overflow-hidden">
              <div className="space-y-3 h-full flex flex-col">
                <div className="text-center flex-shrink-0">
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 via-blue-500/20 to-purple-500/20 rounded-xl blur-lg"></div>
                    <div className="relative flex items-center justify-center gap-4 rounded-xl px-10 py-5 border-2 bg-gradient-to-r from-purple-500/40 via-blue-500/40 to-purple-500/40 border-purple-400/60 backdrop-blur-sm shadow-xl">
                      <span className="text-2xl font-bold uppercase tracking-[0.1em] text-white">
                        🎪 {activeFormCopy.badge} 🎪
                        {mode === 'login' && me && (me as any).username && (
                          <div className="text-lg font-normal normal-case mt-1 text-blue-200">
                            Zdravo, {(me as any).username}! 👋
                          </div>
                        )}
                      </span>
                    </div>
                  </div>
                  <h2 className="mt-3 text-xl font-bold bg-gradient-to-r from-white via-purple-100 to-blue-100 bg-clip-text text-transparent">
                    {activeFormCopy.title}
                  </h2>
                  <p className="mt-2 text-xs text-white/90 leading-relaxed max-w-sm mx-auto">
                    {activeFormCopy.subtitle}
                  </p>
                </div>

                {/* form - spuštena niže ali ne skroz */}
                <div className="flex-1 flex flex-col justify-start pt-4">
                  <div className="space-y-3">
                    {/* PUMPAJ info button - POVEĆAN I SPUŠTEN */}
                    <div className="relative group mb-4">
                      <style dangerouslySetInnerHTML={{
                        __html: `
                          @keyframes redPulse {
                            0%, 100% {
                              background-color: rgba(147, 51, 234, 0.3);
                              border-color: rgba(168, 85, 247, 0.5);
                              color: rgb(196, 181, 253);
                              box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
                            }
                            50% {
                              background-color: rgba(220, 38, 38, 0.4);
                              border-color: rgba(248, 113, 113, 0.7);
                              color: rgb(254, 202, 202);
                              box-shadow: 0 25px 50px -12px rgba(220, 38, 38, 0.4), 0 0 30px rgba(248, 113, 113, 0.6), 0 0 60px rgba(248, 113, 113, 0.3);
                            }
                          }
                          .red-pulse {
                            animation: redPulse 2s ease-in-out infinite;
                          }
                          @keyframes shimmer {
                            0% {
                              transform: translateX(-100%);
                            }
                            100% {
                              transform: translateX(100%);
                            }
                          }
                          .animate-shimmer {
                            animation: shimmer 2s ease-in-out infinite;
                          }
                        `
                      }} />
                      <button
                        type="button"
                        onClick={() => setShowPumpajInfo(true)}
                        className="relative w-full rounded-full border px-6 py-3 text-base font-bold uppercase tracking-wide red-pulse transition-all duration-300 hover:scale-[1.02] overflow-hidden"
                      >
                        {/* Floating circles */}
                        <div className="absolute top-1 left-4 w-2 h-2 bg-white/20 rounded-full animate-ping"></div>
                        <div className="absolute top-3 right-6 w-1.5 h-1.5 bg-purple-300/30 rounded-full animate-ping delay-300"></div>
                        <div className="absolute bottom-2 left-8 w-1 h-1 bg-blue-300/40 rounded-full animate-ping delay-700"></div>
                        <div className="absolute bottom-1 right-4 w-2.5 h-2.5 bg-pink-300/25 rounded-full animate-ping delay-1000"></div>
                        <div className="absolute top-2 left-1/2 w-1.5 h-1.5 bg-cyan-300/35 rounded-full animate-ping delay-500"></div>
                        
                        <span className="relative z-10">
                          {language === 'sr' ? 'Šta znači PUMPAJ u Srbiji?' : 'What does PUMPAJ mean in Serbia?'}
                        </span>
                      </button>
                    </div>
                  </div>
                  
                  <div className="space-y-2 mt-6">
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder={`👤 ${copy.placeholders.username}`}
                      autoComplete="username"
                      className="w-full rounded-xl border border-white/20 bg-slate-900/70 backdrop-blur-xl px-5 py-3.5 text-white placeholder-white/60 outline-none transition-all duration-300 focus:border-purple-400/70 focus:ring-2 focus:ring-purple-400/20 hover:border-white/40 hover:bg-slate-900/80"
                    />

                    {mode === 'register' && (
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder={`📧 ${copy.placeholders.email}`}
                        autoComplete="email"
                        className="w-full rounded-xl border border-white/20 bg-slate-900/70 backdrop-blur-xl px-5 py-3.5 text-white placeholder-white/60 outline-none transition-all duration-300 focus:border-purple-400/70 focus:ring-2 focus:ring-purple-400/20 hover:border-white/40 hover:bg-slate-900/80"
                      />
                    )}

                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder={`🔒 ${copy.placeholders.password}`}
                      autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                      className="w-full rounded-xl border border-white/20 bg-slate-900/70 backdrop-blur-xl px-5 py-3.5 text-white placeholder-white/60 outline-none transition-all duration-300 focus:border-purple-400/70 focus:ring-2 focus:ring-purple-400/20 hover:border-white/40 hover:bg-slate-900/80"
                    />

                    {error && (
                      <div className="rounded-lg border border-red-500/40 bg-red-500/15 px-3 py-2 text-xs text-red-200">
                        {error}
                      </div>
                    )}

                    {/* Quick Login Options - only for login mode */}
                    {mode === 'login' && (
                      <div className="mt-4 space-y-3">
                        <div className="text-center">
                          <span className="text-sm uppercase tracking-wider text-white/60">Quick Login and register</span>
                        </div>
                        <div className="flex gap-3">
                          <button className="flex items-center justify-center gap-2 flex-1 px-3 py-2.5 rounded-lg border border-white/20 bg-white/5 hover:bg-white/10 transition-all text-sm text-white/80 hover:text-white">
                            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                            </svg>
                            Google
                          </button>
                          <button className="flex items-center justify-center gap-2 flex-1 px-3 py-2.5 rounded-lg border border-white/20 bg-white/5 hover:bg-white/10 transition-all text-sm text-white/80 hover:text-white">
                            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                            </svg>
                            Facebook
                          </button>
                        </div>
                        <div className="text-center">
                          <div className="flex items-center gap-3">
                            <div className="h-px flex-1 bg-white/20"></div>
                            <span className="text-sm text-white/50">or use email</span>
                            <div className="h-px flex-1 bg-white/20"></div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* buttons */}
                <div className="space-y-2 flex-shrink-0">
                  <button
                    type="button"
                    onClick={() => { setMode('login'); setError(''); if (mode !== 'login') return; handleSubmit(); }}
                    disabled={submitting}
                    className={`w-full rounded-xl border px-6 py-4 font-bold transition-all duration-300 backdrop-blur-xl ${
                      mode === 'login'
                        ? 'border-purple-400/50 bg-gradient-to-r from-purple-600/90 via-blue-600/90 to-purple-600/90 text-white shadow-xl shadow-purple-500/30'
                        : 'border-white/20 bg-slate-900/40 text-white/80 hover:border-purple-400/30 hover:bg-slate-900/60 hover:text-white'
                    } disabled:cursor-not-allowed disabled:opacity-60`}
                  >
                    <span className="flex items-center justify-center gap-3">
                      {submitting && mode === 'login'
                        ? (<><div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> {activeFormCopy.submittingLabel}</>)
                        : (<><span className="text-xl">🔑</span>{copy.tabs.login}</>)}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => { setMode('register'); setError(''); if (mode !== 'register') return; handleSubmit(); }}
                    disabled={submitting}
                    className={`w-full rounded-xl border px-6 py-4 font-bold transition-all duration-300 backdrop-blur-xl ${
                      mode === 'register'
                        ? 'border-blue-400/50 bg-gradient-to-r from-blue-600/90 via-purple-600/90 to-blue-600/90 text-white shadow-xl shadow-blue-500/30'
                        : 'border-white/20 bg-slate-900/40 text-white/80 hover:border-blue-400/30 hover:bg-slate-900/60 hover:text-white'
                    } disabled:cursor-not-allowed disabled:opacity-60`}
                  >
                    <span className="flex items-center justify-center gap-3">
                      {submitting && mode === 'register'
                        ? (<><div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> {activeFormCopy.submittingLabel}</>)
                        : (<><span className="text-xl">✨</span>{copy.tabs.register}</>)}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Pumpaj modal */}
      {showPumpajInfo && (
        <div
          className="fixed inset-0 z-[9999] flex items-center justify-center p-20"
          role="dialog"
          aria-modal="true"
          onClick={() => setShowPumpajInfo(false)}
          style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)' }}
        >
          <div className="relative max-w-3xl w-full max-h-[85vh] animate-in fade-in-0 zoom-in-95 duration-500 ease-out" onClick={(e) => e.stopPropagation()}>
            <div className="absolute -top-32 left-1/2 -translate-x-1/2 z-10">
              <img src="/pumpaj-192.png?v=3" alt="Pumpaj logo" className="shadow-2xl" />
            </div>
            <div className="bg-gradient-to-br from-slate-800/98 via-purple-900/98 to-red-900/98 backdrop-blur-3xl rounded-2xl border-2 border-white/30 shadow-2xl overflow-hidden">
              <div className="p-6 text-center relative">
                <button
                  aria-label="Close"
                  onClick={() => setShowPumpajInfo(false)}
                  className="absolute top-4 right-4 text-white/60 hover:text-white transition-colors text-2xl hover:scale-110 transform duration-200 p-2 rounded-full hover:bg-white/10"
                >
                  ✕
                </button>
                <div className="flex items-center justify-center mb-4 gap-3">
                  <div className="text-3xl">🇷🇸</div>
                  <h3 className="text-3xl font-black bg-gradient-to-r from-red-400 via-blue-400 to-white bg-clip-text text-transparent">
                    {language === 'sr' ? 'PUMPAJ REVOLUCIJA' : 'PUMPAJ REVOLUTION'}
                  </h3>
                </div>
                <div className="overflow-y-auto max-h-[70vh] px-2 text-base leading-relaxed">
                  <PumpajMessage language={language} />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
        </div>
      </div>
    </div>
  );
}

export function RootAuth({ children }: { children: React.ReactNode }) {
  return (
    <AuthProvider>
      <LoginGate>{children}</LoginGate>
    </AuthProvider>
  );
}

/* ============================ Helpers ============================ */

export function FeatureGuard({ children, plan = 'FREE', fallback }: { children: React.ReactNode; plan?: Plan; fallback?: React.ReactNode }) {
  const { policy } = useAuth();
  const currentPlan = policy?.plan ?? 'FREE';
  if (plan === 'FREE') return <>{children}</>;
  if (currentPlan === 'PREMIUM') return <>{children}</>;
  return <>{fallback ?? null}</>;
}

function derivePolicy(plan: Plan | null | undefined): Policy {
  return POLICY_DEFAULTS[plan === 'FREE' ? 'FREE' : 'PREMIUM'];
}

function normalizeUser(raw: any): User {
  if (!raw) return null;
  const plan: Plan = raw.plan === 'FREE' ? 'FREE' : 'PREMIUM';
  return {
    id: String(raw.id ?? 'me'),
    email: raw.email || undefined,
    username: raw.username || undefined,
    plan,
  };
}

const authUrl = (path: string) => {
  const suffix = path.startsWith('/') ? path : `/${path}`;
  return `${API_BASE}/auth${suffix}`;
};
