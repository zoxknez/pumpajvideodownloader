// (obsolete) Vite-specific env types are not used in Next.js app.
// Keeping this file empty to avoid accidental global type pollution.
