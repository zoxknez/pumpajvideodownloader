import type { Request, Response, NextFunction } from 'express';
import { randomUUID } from 'node:crypto';

export function requestLogger(req: Request, res: Response, next: NextFunction) {
  const id = (req.headers['x-request-id'] as string) || randomUUID();
  (req as any).id = id;
  res.setHeader('x-request-id', id);
  const start = process.hrtime.bigint();
  res.on('finish', () => {
    const shouldQuiet = process.env.VERBOSE_REQUEST_LOGS !== '1' && isQuietRequest(req, res.statusCode);
    if (shouldQuiet) return;
    const durMs = Number((process.hrtime.bigint() - start) / 1_000_000n);
    // Minimal JSON line with no PII-heavy payloads
    console.info(JSON.stringify({
      t: new Date().toISOString(),
      id, ip: req.ip, m: req.method, p: req.path, s: res.statusCode, durMs,
    }));
  });
  next();
}

const QUIET_PATHS = new Set([
  '/health',
  '/api/health',
  '/api/jobs/metrics',
  '/api/jobs/settings',
  '/api/history',
  '/api/version',
]);

const QUIET_PREFIXES = ['/api/job/file/'];

function isQuietRequest(req: Request, statusCode: number) {
  const method = req.method;
  const path = req.path || req.originalUrl || '';

  if (method === 'OPTIONS') return true;
  if ((method === 'GET' || method === 'HEAD') && QUIET_PATHS.has(path)) return true;

  if (QUIET_PREFIXES.some((prefix) => path.startsWith(prefix))) {
    if (method === 'HEAD') return true;
    if (method === 'GET' && (statusCode === 200 || statusCode === 304 || statusCode === 404)) return true;
  }

  if (statusCode === 304 && (method === 'GET' || method === 'HEAD')) return true;

  return false;
}
